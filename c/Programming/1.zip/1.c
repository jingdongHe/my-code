#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<time.h>
#define M 1000
typedef struct node{
	int big;
	int small;
	struct node *next;
}link;
link *b_link()
{
	link *p;
	p=(link *)malloc(sizeof(link));
	p->next=NULL;
	return p;
}
void push(link *p,int a,int b)
{
	link *p1;
	p1=(link *)malloc(sizeof(link));
	p1->big=a;
	p1->small=b;
	p1->next=p->next;
	p->next=p1;
}
void Rand1000()
{
	int i;
	int a[M]={0};
	FILE *p1;
	p1=fopen("1.dat","w");
	srand((unsigned  int )time(0));
	for(i=0;i<M;i++)
		fprintf(p1,"%d ",rand());
	fclose(p1);
}
void input(int a[],int n)
{
	int i;
	FILE *p1;
	p1=fopen("1.dat","r");
	for(i=0;i<M;i++)
		fscanf(p1,"%d",&a[i]);
	//a[i-1]=3;
	fclose(p1);
}
void output(int a[],int n)
{
	int i;
	for(i=0;i<n;i++)
		printf("%d ",a[i]);
	printf("\n");
}
void digitcount(int a[],int n,int b[10])
{
	int i,d;
	for(i=0;i<n;i++)
	{
		d=a[i];
		while(d!=0)
		{
			b[d%10]++;
			d=d/10;
		}
	}
}
int maxprime(int a[],int n)
{
	int i,j,d,k=0;
	for(i=0;i<n;i++)
	{
		d=0;
		for(j=2;j<sqrt(a[i]+1);j++)
		{
			if(a[i]%j==0&&a[i]!=j)//d=0������,d=1��������
			{d=1;break;}
		}
		if(d==0&&a[i]>k)
			k=a[i];
	}
	return k;
}
int qss(int a[],int i,int j)
{
	int x;
	x=a[i];
	while(i<j)
	{
		while(i<j&&a[j]>=x)
			j--;
		a[i]=a[j];
		while(i<j&&a[i]<=x)
			i++;
		a[j]=a[i];
	}
	a[i]=x;
	return i;
}
void QS(int a[],int i,int j)
{
	int k;
	if(i<j)
	{
		k=qss(a,i,j);
		QS(a,i,k-1);
		QS(a,k+1,j);
	}
	return ;
}
void FREE(link *p)
{
	link *p1,*p2;
	p1=p->next;
	p->next=NULL;
	while(p1!=NULL)
	{
		p2=p1;
		p1=p1->next;
		free(p2);
	}
}
void output_link(link *p)
{
	link *p1;
	p1=p->next;
	while(p1!=NULL)
	{
		printf("%d...%d",p1->big,p1->small);
		p1=p1->next;
		printf("\n");
	}
}
void difference_max_min(int a[])
{
	int i,k;
	//int j,b,c,d;
	int Max=0,Min=999;
	link *p1,*p2;
	p1=b_link();
	p2=b_link();//p1������ֵ���Ķ�������p2������ֵ��С�Ķ�����
	//printf("1111111111111111111111\n");
	for(i=1;i<M;i++)
	{
		k=a[i]-a[i-1];
		//printf("%d ",k);
		if(k<Min)
		{FREE(p1);push(p1,a[i],a[i-1]);Min=k;continue;}
		//printf("2222222222222222222222\n");
		if(k==Min)
		{push(p1,a[i],a[i-1]);continue;}
		//printf("3333333333333333333333\n");
		if(k>Max)
		{FREE(p2);push(p2,a[i],a[i-1]);Max=k;continue;}
		//printf("44444444444444444444444\n");
		if(k==Max)
		{push(p2,a[i],a[i-1]);continue;}
		//printf("55555555555555555555555\n");
	}
	printf("\n��������֮����С�ļ���Ϊ:\n");
	output_link(p1);
	printf("֮�����ļ���Ϊ:\n");
	output_link(p2);
}
void main()
{
	int a[1000];
	int b[10]={0};
	//int k;
	Rand1000();
	input(a,M);
	output(a,M);
	printf("ÿλ���ֳ��ֵĴ���Ϊ:\n");
	digitcount(a,M,b);
	output(b,10);
	printf("==========================================\n");
	if(maxprime(a,M))
	{
		printf("��������Ϊ:%d\n",maxprime(a,M));
	}
	else
		printf("�������������\n");
	printf("==========================================\n");
	printf("���������Ϊ:\n");
	QS(a,0,M-1);
	output(a,M);
	printf("==========================================\n");
	difference_max_min(a);
	
}